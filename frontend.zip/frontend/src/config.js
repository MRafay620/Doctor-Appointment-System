// export const BASE_URL='http://localhost:5000/api/v1';
// export const token = localStorage.getItem("token");
export const BASE_URL = 'http://localhost:5000/api/v1';
export const token = localStorage.getItem("token");
